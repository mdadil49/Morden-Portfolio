// For cv download 
let cvBtn = document.getElementById("cvBtn");
let submit = document.getElementById("submit");

cvBtn.addEventListener("click", function(){
    alert("Download succesfull")
})

submit.addEventListener("click", function(){
    let email = document.getElementById("email")
    let pass = document.getElementById("pass")

    if(email.value == "" && pass.value == ""){
        alert("Fill Details")
    }
})